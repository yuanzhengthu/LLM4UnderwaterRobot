# GENERATED VERSION FILE
# TIME: Sat Jun  1 02:50:14 2024
__version__ = '0.3.0'
__gitsha__ = 'unknown'
version_info = (0, 3, 0)
