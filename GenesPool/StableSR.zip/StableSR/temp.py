import os
from huggingface_hub import HfFolder, get_full_repo_name

repo_id = get_full_repo_name("your_model_repo")  # Replace with your model repo
cache_dir = HfFolder.get_cache_home(repo_id)

if os.path.exists(cache_dir):
    print(f"Removing the existing cache at {cache_dir}")
    import shutil
    shutil.rmtree(cache_dir)